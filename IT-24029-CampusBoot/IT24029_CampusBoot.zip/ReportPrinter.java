public class ReportPrinter { }
